public class HotelApplication {
    public static void main(String[] args) {
        MainMenu.main();
    }
}
